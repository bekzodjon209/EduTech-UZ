# EduTech UZ

O‘zbekiston texnikumlari uchun ochiq kodli, o‘zbek tilidagi oddiy raqamli ta’lim dasturi.

## Imkoniyatlar
- Fan va mavzularni ko‘rish
- Nazariy matnlarni o‘qish
- Uch variantli test ishlash
- Yangi mavzu va test qo‘shish
- Ma’lumotlarni `courses.json` faylida saqlash

## Ishga tushirish
Python 3.10+ o‘rnating va terminalda:

```bash
python app.py
```

Dastur Python standart kutubxonasi (`tkinter`) bilan ishlaydi. Internet shart emas.

## Windows EXE yig‘ish

```bash
pip install pyinstaller
pyinstaller --onefile --windowed --name EduTechUZ app.py
```

Tayyor fayl `dist/EduTechUZ.exe` ichida bo‘ladi. EXE ni Windows kompyuterda yig‘ing.

## Hissa qo‘shish
Issue oching yoki pull request yuboring. Haqiqiy takliflar, tuzatishlar va tarjimalar qabul qilinadi.

## Litsenziya
MIT
