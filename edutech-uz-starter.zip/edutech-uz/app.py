import json
from pathlib import Path
import tkinter as tk
from tkinter import ttk, messagebox

DATA = Path(__file__).with_name('courses.json')
DEFAULT = [{"fan":"Avtomobillar tuzilishi","mavzu":"Ichki yonuv dvigateli","nazariya":"Dvigatel yoqilg'i energiyasini mexanik energiyaga aylantiradi.","savol":"Dvigatel qanday energiya hosil qiladi?","variantlar":["Mexanik", "Kimyoviy", "Yorug'lik"],"javob":0}]

def load():
    if not DATA.exists(): return DEFAULT.copy()
    try:
        items=json.loads(DATA.read_text(encoding='utf-8'))
        return items if isinstance(items,list) else DEFAULT.copy()
    except (OSError,ValueError): return DEFAULT.copy()

def save(items):
    DATA.write_text(json.dumps(items,ensure_ascii=False,indent=2),encoding='utf-8')

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title('EduTech UZ — Raqamli ta’lim'); self.geometry('850x580')
        self.items=load()
        self.listbox=tk.Listbox(self,width=35,font=('Arial',11))
        self.listbox.pack(side='left',fill='y',padx=12,pady=12)
        self.listbox.bind('<<ListboxSelect>>',self.show)
        right=ttk.Frame(self,padding=15); right.pack(fill='both',expand=True)
        self.title_label=ttk.Label(right,text='Mavzuni tanlang',font=('Arial',16,'bold')); self.title_label.pack(anchor='w')
        self.text=tk.Text(right,height=12,wrap='word',font=('Arial',11)); self.text.pack(fill='both',expand=True,pady=10)
        ttk.Button(right,text='Testni boshlash',command=self.quiz).pack(fill='x',pady=4)
        ttk.Button(right,text='Yangi mavzu qo‘shish',command=self.add).pack(fill='x',pady=4)
        self.refresh()
    def refresh(self):
        self.listbox.delete(0,'end')
        for item in self.items: self.listbox.insert('end',f"{item['fan']} — {item['mavzu']}")
    def selected(self):
        sel=self.listbox.curselection()
        return self.items[sel[0]] if sel else None
    def show(self,event=None):
        item=self.selected()
        if item:
            self.title_label.config(text=item['mavzu'])
            self.text.delete('1.0','end'); self.text.insert('1.0',item['nazariya'])
    def quiz(self):
        item=self.selected()
        if not item: return messagebox.showinfo('Tanlash','Avval mavzuni tanlang.')
        dialog=tk.Toplevel(self); dialog.title('Bilimni tekshirish'); dialog.geometry('450x250')
        ttk.Label(dialog,text=item['savol'],wraplength=400).pack(pady=15)
        answer=tk.IntVar(value=-1)
        for i,v in enumerate(item['variantlar']): ttk.Radiobutton(dialog,text=v,variable=answer,value=i).pack(anchor='w',padx=25)
        def check():
            if answer.get()<0: return
            messagebox.showinfo('Natija','To‘g‘ri javob!' if answer.get()==item['javob'] else 'Noto‘g‘ri javob. Qayta urinib ko‘ring.')
        ttk.Button(dialog,text='Tekshirish',command=check).pack(pady=12)
    def add(self):
        dialog=tk.Toplevel(self); dialog.title('Yangi mavzu'); dialog.geometry('540x520')
        fields={}
        labels=[('fan','Fan'),('mavzu','Mavzu'),('nazariya','Nazariya'),('savol','Test savoli'),('a','A variant'),('b','B variant'),('c','C variant')]
        for key,label in labels:
            ttk.Label(dialog,text=label).pack(anchor='w',padx=15)
            entry=ttk.Entry(dialog,width=70);entry.pack(padx=15,pady=3);fields[key]=entry
        ttk.Label(dialog,text='To‘g‘ri javob').pack()
        correct=ttk.Combobox(dialog,values=['A','B','C'],state='readonly');correct.set('A');correct.pack()
        def submit():
            values={k:v.get().strip() for k,v in fields.items()}
            if not all(values.values()):return messagebox.showwarning('Xatolik','Barcha maydonlarni to‘ldiring.')
            self.items.append({"fan":values['fan'],"mavzu":values['mavzu'],"nazariya":values['nazariya'],"savol":values['savol'],"variantlar":[values['a'],values['b'],values['c']],"javob":'ABC'.index(correct.get())})
            try:save(self.items)
            except OSError as e:return messagebox.showerror('Saqlash xatosi',str(e))
            self.refresh();dialog.destroy()
        ttk.Button(dialog,text='Saqlash',command=submit).pack(pady=12)

if __name__=='__main__': App().mainloop()
